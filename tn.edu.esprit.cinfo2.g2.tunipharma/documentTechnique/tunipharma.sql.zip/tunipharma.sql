-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 09 Juillet 2014 à 22:42
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `tunipharma`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) COLLATE utf8_bin NOT NULL,
  `lasname` int(250) NOT NULL,
  `login` int(250) NOT NULL,
  `password` int(250) NOT NULL,
  `email` int(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `drug_store`
--

CREATE TABLE IF NOT EXISTS `drug_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `sector` varchar(255) COLLATE utf8_bin NOT NULL,
  `region` varchar(255) COLLATE utf8_bin NOT NULL,
  `adress` varchar(255) COLLATE utf8_bin NOT NULL,
  `telephone` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `web_site` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=44 ;

--
-- Contenu de la table `drug_store`
--

INSERT INTO `drug_store` (`id`, `name`, `sector`, `region`, `adress`, `telephone`, `email`, `web_site`) VALUES
(20, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(21, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(22, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(23, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(24, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(25, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(26, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(27, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(28, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(29, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(30, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(31, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(32, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(34, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(35, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(36, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(37, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(38, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(39, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(40, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(41, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(42, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com'),
(43, 'Drugstore laouina', 'night', 'Laouina', 'Rue ezzoouhour Laouina', '71548975', 'drugstore_laouina@gmail.com', 'drugstore_laouina@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_store_id` int(255) NOT NULL,
  `subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `content` varchar(255) COLLATE utf8_bin NOT NULL,
  `start_time` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `drug_store_id` (`drug_store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `operator`
--

CREATE TABLE IF NOT EXISTS `operator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_store_id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8_bin NOT NULL,
  `lasname` varchar(255) COLLATE utf8_bin NOT NULL,
  `login` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `drug_store_id` (`drug_store_id`),
  KEY `drug_store_id_2` (`drug_store_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=20 ;

--
-- Contenu de la table `operator`
--

INSERT INTO `operator` (`id`, `drug_store_id`, `firstname`, `lasname`, `login`, `password`, `email`) VALUES
(3, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'null'),
(4, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'null'),
(5, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'null'),
(6, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'null'),
(7, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'null'),
(8, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(9, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null'),
(10, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(11, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null'),
(12, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(13, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null'),
(14, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(15, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null'),
(16, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(17, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null'),
(18, 20, 'Salem', 'Belanes', 'login.salem', 'scretSalem', 'benSalah_ali@gmail.com'),
(19, 20, 'Ali', 'Ben salah', 'login.ali', 'scretAli', 'null');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`drug_store_id`) REFERENCES `drug_store` (`id`);

--
-- Contraintes pour la table `operator`
--
ALTER TABLE `operator`
  ADD CONSTRAINT `operator_ibfk_1` FOREIGN KEY (`drug_store_id`) REFERENCES `drug_store` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
